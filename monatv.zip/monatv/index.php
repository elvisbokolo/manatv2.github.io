<?php


	session_start();
		include('chemin.php');


	include 'views/index.views.php';