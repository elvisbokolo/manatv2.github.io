<?php

	$titre = "";
	$assets = "assets";
	$chemin = "";