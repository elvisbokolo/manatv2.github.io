<footer class="footer mt-5">
	<div class="container-fluid mt-5">
		<nav class="navbar fixed-bottom navbar-dark bg-secondary justify-content-between" >
			<a class="nav-link text-white active" href="categorie.php">
				<i class="fas fa-clipboard-list" style="font-size: 20px;"></i>
			</a>
			<a class="nav-link text-secondary bg-light" style="border-radius: 100%;" href="index.php">
				<i class="fas fa-home mt-2 mb-2 " style="font-size: 20px;"></i>
			</a>
			<a class="nav-link text-white" href="favorie.php">
				<i class="fas fa-star" style="font-size: 20px;"></i>
			</a>
		</nav>
	</div>
</footer>