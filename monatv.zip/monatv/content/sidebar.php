<div class="sidebar sidebar-style-2">
	<div class="sidebar-wrapper scrollbar scrollbar-inner">
		<div class="sidebar-content">
			<div class="user">
				<div class="float-left mr-2 mb-3">
					<img src="<?= $assets ?>/img/chaine/logomonacopie.png" alt="..." class="avatar-img mt--4" style="height: 80px;">
				</div>
			</div>
			<ul class="nav nav-primary">
				<li class="nav-item active">
					<a href="#" class="" >
						<i class="fas fa-home"></i>
						<p>Dashboard</p>
						<!-- <span class="caret"></span> -->
					</a>
				</li>
				<li class="nav-section">
					<span class="sidebar-mini-icon">
						<i class="fa fa-ellipsis-h"></i>
					</span>
					<h4 class="text-section">Components</h4>
			</ul>
		</div>
	</div>
</div>