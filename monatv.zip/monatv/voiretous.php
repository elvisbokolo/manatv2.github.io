<?php


	session_start();
		include('chemin.php');
		// require('dbconnect/dbconnect.php');
		// require('fonction/fonction.php');


	include 'views/voiretous.views.php';